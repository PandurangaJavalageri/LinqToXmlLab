﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Linq_to_Xml_Lab
{
    internal class Program
    {
        static void Main(string[] args)
        {

            XDocument xml = XDocument.Load("XMLFIle1.xml");
            Console.WriteLine(xml);
            var employ = from emp in xml.Descendants("Employee") select emp.Element("Name").Value;
            foreach (var emp in employ)
            {
                Console.WriteLine(emp);
            }
            Console.WriteLine();
            Console.WriteLine();
            var empl = from emp in xml.Descendants("Employee") select (emp.Element("EmpId"), emp.Element("Name"));
            foreach (var emp in empl)
            {
                Console.WriteLine(emp.Item1.Value + " " + emp.Item2.Value);
            }
            var fempl = from emp in xml.Descendants("Employee") where emp.Element("Sex").Value == "Female" select (emp.Element("Name").Value);
            foreach (var emp in fempl)
            {
                Console.WriteLine(emp);
            }
            var pno = from emp in xml.Descendants("Employee")
                      let l = emp.Element("Phone")
                      where (string)l.Attribute("Type") == "Home"
                      select emp.Element("Phone").Value;
            foreach (var emp in pno)
            {
                Console.WriteLine(emp);
            }
            var cempl = from emp in xml.Descendants("Employee") let l = emp.Element("Address").Element("City") where l.Value == "Alta" select emp.Element("Name").Value;
            foreach (var emp in cempl)
            {
                Console.WriteLine(emp);
            }
            var zemp = from emp in xml.Descendants("Employee") orderby emp.Element("Address").Element("Zip").Value select emp;
            foreach (var emp in zemp)
            {
                Console.WriteLine(emp);
            }
            var empl1and2 = (from emp in xml.Descendants("Employee") select emp).Take(2);
            foreach (var emp in empl1and2)
            {
                Console.WriteLine(emp);
            }
            var empca = (from emp in xml.Descendants("Employee") where emp.Element("Address").Element("State").Value == "CA" select emp).Count();
            Console.WriteLine(empca);

            var empnameandcity = from emp in xml.Descendants("Employee") where emp.Element("Sex").Value == "Female" select (emp.Element("Name").Value, emp.Element("Address").Element("City").Value,emp.Element("Sex").Value);
            foreach (var emp in empnameandcity)
            {
                Console.WriteLine(emp.Item1+" "+emp.Item2+" "+emp.Item3);
            }


        }
    }
}
